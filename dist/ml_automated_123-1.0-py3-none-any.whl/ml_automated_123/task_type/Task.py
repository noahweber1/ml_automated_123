from enum import Enum


class Task(Enum):
    CLASSIFICATION = 'classification'
    REGRESSION = 'regression'
