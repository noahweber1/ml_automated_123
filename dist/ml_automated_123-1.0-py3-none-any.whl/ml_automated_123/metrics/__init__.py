from .accuracy import accuracy
from .f1 import f1
from .precision import precision
from .recall import recall
from .r2 import r2
