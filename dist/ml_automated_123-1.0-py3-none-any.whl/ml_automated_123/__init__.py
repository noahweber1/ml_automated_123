from .readers import *
from .package import automate, predict

__version__ = '0.1.0'
